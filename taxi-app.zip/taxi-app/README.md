# Taxi App

MERN stack template for a taxi booking platform.